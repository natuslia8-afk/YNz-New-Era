package com.ynz.newera;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(255, 25, 45);
    private static final int DARK = Color.rgb(10, 7, 12);
    private static final String PASSWORD = "YNZ NEW ERA";
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DARK);
        getWindow().setNavigationBarColor(DARK);
        showLogin();
    }

    private GradientDrawable panel(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{color, Color.rgb(24, 8, 15)});
        d.setCornerRadius(radius);
        d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(12, 10, 12, 10);
        return t;
    }

    private LinearLayout page() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(22, 28, 22, 28);
        root.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(35, 3, 13), DARK, Color.rgb(22, 4, 12)}));
        scroll.addView(root);
        setContentView(scroll);
        return root;
    }

    private void addSpace(int h) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, h));
    }

    private void addButton(String label, Runnable action, boolean filled) {
        TextView b = text(label, 16, Color.WHITE, true);
        b.setBackground(panel(filled ? Color.rgb(125, 0, 18) : DARK, RED, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 54);
        p.setMargins(0, 8, 0, 8);
        root.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }

    private void showLogin() {
        page();
        addSpace(35);
        root.addView(text("☠", 48, RED, true));
        root.addView(text("YNZ", 48, Color.WHITE, true));
        root.addView(text("NEW ERA", 34, RED, true));
        root.addView(text("— ACCESS SYSTEM —", 12, Color.LTGRAY, true));
        addSpace(28);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(14, 18, 14, 18);
        card.setBackground(panel(DARK, RED, 22));
        root.addView(card, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, -2));
        TextView title = text("🔒  ENTER PASSWORD", 18, Color.WHITE, true);
        card.addView(title);

        EditText pass = new EditText(this);
        pass.setSingleLine(true);
        pass.setTextColor(Color.WHITE);
        pass.setHintTextColor(Color.LTGRAY);
        pass.setHint("Masukkan password...");
        pass.setGravity(Gravity.CENTER);
        pass.setInputType(129);
        pass.setBackground(panel(Color.rgb(35, 27, 38), Color.DKGRAY, 12));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, 52);
        ep.setMargins(0, 12, 0, 10);
        card.addView(pass, ep);

        TextView ok = text("MASUK", 17, Color.WHITE, true);
        ok.setBackground(panel(Color.rgb(150, 0, 18), RED, 14));
        card.addView(ok, new LinearLayout.LayoutParams(-1, 52));
        ok.setOnClickListener(v -> {
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(pass.getWindowToken(), 0);
            if (PASSWORD.equals(pass.getText().toString().trim())) showHome();
            else Toast.makeText(this, "Password salah!", Toast.LENGTH_SHORT).show();
        });

        addSpace(12);
        addButton("➤  GET PASSWORD", this::openTelegram, false);
        addSpace(25);
        root.addView(text("© YNZ NEW ERA • ALL RIGHTS RESERVED", 11, Color.LTGRAY, false));
    }

    private void openTelegram() {
        // Ganti username ini dengan username Telegram milik developer.
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ynz_newera"));
        startActivity(i);
    }

    private void showHome() {
        page();
        addSpace(12);
        root.addView(text("YNZ", 44, Color.WHITE, true));
        root.addView(text("NEW ERA", 32, RED, true));
        root.addView(text("— BUG COLLECTION —", 12, Color.LTGRAY, true));
        addSpace(18);
        root.addView(text("PILIH MENU", 18, RED, true));
        addButton("☠   CRASH BIASA", () -> showInfo("Crash Biasa"), true);
        addButton("☠   CRASH PARAH", () -> showInfo("Crash Parah"), true);
        addButton("☠   BANNED", () -> showInfo("Banned"), true);

        LinearLayout target = new LinearLayout(this);
        target.setGravity(Gravity.CENTER);
        target.setPadding(10, 12, 10, 12);
        target.setBackground(panel(DARK, RED, 18));
        TextView targetText = text("◎   TARGET", 18, RED, true);
        target.addView(targetText);
        root.addView(target, new LinearLayout.LayoutParams(-1, 58));
        addSpace(12);
        addButton("PROFIL DEVELOPER", this::showProfile, false);
        addButton("KELUAR", this::showLogin, false);
        root.addView(text("SIMULASI UI • TIDAK MENYERANG PERANGKAT/AKUN", 10, Color.LTGRAY, false));
    }

    private void showInfo(String name) {
        new android.app.AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage("Ini hanya contoh tampilan/demo. Tidak ada proses crash, pemblokiran, atau tindakan terhadap perangkat maupun akun.")
            .setPositiveButton("KEMBALI", (d, w) -> {})
            .show();
    }

    private void showProfile() {
        page();
        addSpace(30);
        root.addView(text("◉", 56, RED, true));
        root.addView(text("YNZ NEW ERA", 28, Color.WHITE, true));
        root.addView(text("DEVELOPER & CREATOR", 14, RED, true));
        addSpace(18);
        root.addView(text("“Build with purpose. Create a new era.”", 16, Color.LTGRAY, false));
        addSpace(20);
        root.addView(text("Tentang Kami", 20, RED, true));
        root.addView(text("YNZ NEW ERA — ruang kreasi untuk eksperimen UI, desain, dan pembelajaran keamanan digital yang bertanggung jawab.", 15, Color.WHITE, false));
        addSpace(18);
        root.addView(text("TELEGRAM: @ynz_newera", 15, Color.WHITE, true));
        addButton("HUBUNGI DEVELOPER", this::openTelegram, true);
        addButton("KEMBALI KE MENU", this::showHome, false);
    }
}
